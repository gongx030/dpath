library(Matrix)
library(igraph)
library(irlba)
library(kohonen)
library(parallel)
library(fields)
library(colorspace)
library(gplots)
library(FNN)
library(hopach)

# --------------------------------------------------------------------
# Created: 2015-02-02
# Poisson mixture non-negative matrix factorization 
# X: a gene by cell matrix of TPM
# --------------------------------------------------------------------
dpath <- function(X, K = 5, xdim = 10, ydim = 10, lambda0 = 0.1, w0 = 0.1, min.expressed = 2, max.expressed = 1, max.iter.wnmf = 200, max.iter.wpnmf = 1000, repeat.mf = 10, repeat.bootstrap = 100, n.bootstrap = 1000, mc.cores = 8){

	if (class(X) != 'matrix')
		stop('X must be a numeric matrix')
	
	if (any(X < 0))
		stop('there exists negative entries in expression matrix X; all entries in X must be non-negative')
	
	K <- as.integer(K)
	if (is.na(K) || K <= 0)
		stop('K must be a positive integer')
	
	if (K == 1)
		stop('K must be at least 2')

	if (K > ncol(X))
		stop('K must be smaller than the number of cells')
	
	xdim <- as.integer(xdim)
	ydim <- as.integer(ydim)

	if (xdim <= 1 || ydim <= 1)
		stop('xdim and ydim must be integers > 1')

	if (lambda0 < 0)
		stop('lambda0 must be non-negative')

	if (w0 < 0)
		stop('w0 must be non-negative')

	if (min.expressed < 0 || min.expressed >= ncol(X))
		stop('min.expressed must be non-negative and no larger than the number of cells')

	repeat.mf <- as.integer(repeat.mf)
	if (is.na(repeat.mf) || repeat.mf <= 0)
		stop('repeat.mf must be a positive integer')

	repeat.bootstrap <- as.integer(repeat.bootstrap)
	if (is.na(repeat.bootstrap) || repeat.bootstrap <= 0)
		stop('repeat.bootstrap must be a positive integer')

	n.bootstrap <- as.integer(n.bootstrap)
	if (is.na(n.bootstrap) || n.bootstrap <= 0)
		stop('n.bootstrap must be a positive integer')

	mc.cores <- as.integer(mc.cores)
	if (is.na(mc.cores) || mc.cores<= 0)
		stop('mc.cores be a positive integer')

	cat(sprintf('-----------------------------------------------------------------------\n'))
	cat('dpath: the single cell RNA-seq analysis pipeline\n')
	cat(sprintf('-----------------------------------------------------------------------\n'))

	N <- nrow(X)	# number of genes
	M <- ncol(X)	# number of cells
	eps <- .Machine$double.eps

	cat(sprintf('number of metagenes(K)=%d\n', K))
	cat(sprintf('number of metacells(xdim x ydim)=%dx%d=%d\n', xdim, ydim, xdim * ydim))
	cat(sprintf('lambda for dropout event(lambda0)=%.3f\n', lambda0))
	cat(sprintf('weight for zero TPM(w0)=%.3f\n', w0))
	cat(sprintf('minimum number of expressed cells(expressed.min)=%d\n', min.expressed))
	cat(sprintf('maximum percent of expressed cells(expressed.max)=%.1f%%\n', max.expressed * 100))
	cat(sprintf('sparsity of expression matrix=%.1f%%\n', 100 * (N * M - sum(X > 0)) / (N * M)))
	cat(sprintf('number of input cells=%d\n', M))
	cat(sprintf('number of input genes=%d\n', N))

	n.expressed <- rowSums(X > 1)	# number of expressed cells
	X <- X[n.expressed >= min.expressed & n.expressed <= round(M * max.expressed), , drop = FALSE]	# filter for detected cells
	N <- nrow(X)
	cat(sprintf('number of genes that are expressed in at least %d cells and at most %.1f%% of all cells=%d\n', min.expressed, max.expressed * 100, N))
	cat(sprintf('number of repeated matrix factorization(repeat.mf)=%d\n', repeat.mf))
	cat(sprintf('number of repeated bootstrapping(repeat.bootstrap)=%d\n', repeat.bootstrap))
	cat(sprintf('bootstrapping size(n.bootstrap)=%d\n', n.bootstrap))
	cat(sprintf('number of cores for optimization(mc.cores)=%d\n', mc.cores))
	cat(sprintf('-----------------------------------------------------------------------\n'))

	cat(sprintf('updating basis(U) and coefficient(V): '))
	mf.list <- mclapply(1:repeat.mf, function(r){

		set.seed(r)

		# initializing basis(V)
		V <- irlba(X, nu = K, nv = 1)$u
		m <- kmeans(V, K)$cluster
		V <- as.matrix(as(sparseMatrix(i = m, j = 1:N, dims = c(K, N)), 'dgCMatrix') %*% X)
		V <- V %*% diag(1 / colSums(V))

		# initializing coefficients(U) randomly
		U <- matrix(runif(N * K), nrow = N, ncol = K)

		# initializing weight for weighted NMF
    W <- matrix(0, N, M, dimnames = dimnames(X))
    W[X > 0] <- w0

		iter <- 1
		optval <- NULL
		while (iter <= max.iter.wnmf){

			U <- U * (X %*% t(V) / ( ((U %*% V) * W) %*% t(V) + eps))
			V <- V * (t(U) %*% X / (t(U) %*% ((U %*% V) * W) + eps))
			V <- V %*% diag(1 / colSums(V))

			if (iter == 1 || iter %% 100 == 0){
				cat('.')
				Xp <- U %*% V
				J <- norm((X - Xp) * W, 'F')
				optval <- rbind(optval, data.frame(iter = iter, J = J))
			}
			if (!is.null(optval) && nrow(optval) > 1){
				if (abs(optval[nrow(optval), 'J'] - optval[nrow(optval) - 1, 'J']) < 1e-3)
					break
			}
			iter <- iter + 1
		}

		P1 <- exp(ldpois(X, mu = lambda0))	# probability of being a dropout
		optval <- NULL
		iter <- 1
		W <- matrix(0.5, N, M)
		while (iter <= max.iter.wpnmf){
			U <- U * ( ((W * X / (U %*% V + eps)) %*% t(V)) / (W %*% t(V) + eps) )
			V <- V * ( (t(U) %*% (W * X / (U %*% V + eps))) / (t(U) %*% W + eps) )
			V <- V %*% diag(1 / colSums(V))
			P2 <- exp(ldpois(X, U %*% V))
			W <- P2 / (P1 + P2 + eps)
			if (iter == 1 || iter %% 100 == 0){
				cat('+')
				J <- sum(W * log(P2 + eps) + (1 - W) * log(P1 + eps))
				optval <- rbind(optval, data.frame(iter = iter, J = J))
			}
			if (!is.null(optval) && nrow(optval) > 1){
				if (abs(optval[nrow(optval), 'J'] - optval[nrow(optval) - 1, 'J']) < 1e-3)
					break
			}
			iter <- iter + 1
		}

		cat('$')
		list(U = U, V = V)
	}, mc.cores = mc.cores, mc.preschedule = FALSE, mc.set.seed = FALSE)
	cat('\n')

	V.list <- lapply(mf.list, function(mf) mf$V)	# a list of metagene basis of repeated runs

	# mean similarity between cells
	S.list <- lapply(1:repeat.mf, function(i) 1 / (1 + as.matrix(dist(t(V.list[[i]])))))
	S <- Reduce('+', S.list) / repeat.mf
	diag(S) <- 0

	# for each pair of repeated run, find the most similar metagenes
	C <- matrix(NA, nrow = repeat.mf, ncol = repeat.mf)
	for (i in 1:repeat.mf){
		for (j in 1:repeat.mf){
			g <- max.col(cor(as.matrix(t(V.list[[i]])), as.matrix(t(V.list[[j]]))))
			C[i, j] <- length(unique(g))
		}
	}

	best <- which.max(rowSums(C == K))	# the repeated run that has most distinctive metagene
	for (i in 1:repeat.mf){
		g <- max.col(cor(as.matrix(t(V.list[[best]])), as.matrix(t(V.list[[i]]))))
		if (length(unique(g)) == K){
			V.list[[i]] <- V.list[[i]][g, ]
			mf.list[[i]]$U <- mf.list[[i]]$U[, g]
		}
	}

	U <- Reduce('+', lapply(mf.list[C[best, ] == K], function(mf) mf$U)) / sum(C[best, ] == K)	# combined coefficients(U)
	V <- Reduce('+', V.list[C[best, ] == K]) / sum(C[best, ] == K)	# combined basis(V)
	colnames(V) <- colnames(X)

	som.grid <- somgrid(xdim = xdim, ydim = ydim, topo = 'hexagonal')
	som.list <- fitsom(V, som.grid = som.grid, repeat.bootstrap = repeat.bootstrap, n.bootstrap = n.bootstrap, mc.cores = mc.cores)

	structure(list(
		X = X,	# observed expression levels
		Xp = Reduce('+', lapply(mf.list, function(mf) mf$U %*% mf$V)) / length(mf.list),	# mean estiamted expression levels
		S = S, 	# mean similarity between cells
		mf.list = mf.list,	# matrix factorization from reptitive runs
		U = U, V = V, 	# mean estimated coefficients(U) and basis(V)
		grid = som.grid, som.list = som.list, 
		best = best,
		lambda0 = lambda0,
		w0 = w0,
		min.expressed = min.expressed,
		max.expressed = max.expressed,
		n.bootstrap = n.bootstrap
	), class = 'dpath')

} # end of dpath


# --------------------------------------------------------------------
# Created: 2014-02-03
# Update dpath
# --------------------------------------------------------------------
update.dpath <- function(object, ...){

	param <- list(...)

	if (is.null(param$xdim) || is.na(param$xdim))
		stop('xdim cannot be NA')
	
	if (is.null(param$ydim) || is.na(param$ydim))
		stop('ydim cannot be NA')
	
	if (is.null(param$repeat.bootstrap) || is.na(param$repeat.bootstrap))
		param$repeat.bootstrap <- length(object$som.list)
	
	if (is.null(param$n.bootstrap) || is.na(param$n.bootstrap))
		param$n.bootstrap <- object$n.bootstrap

	if (is.null(param$mc.cores))
		param$mc.cores <- 8

	som.grid <- somgrid(xdim = param$xdim, ydim = param$ydim, topo = 'hexagonal')
	som.list <- fitsom(object$V, som.grid = som.grid, repeat.bootstrap = param$repeat.bootstrap, n.bootstrap = param$n.bootstrap, mc.cores = param$mc.cores)
	object$grid <- som.grid
	object$som.list <- som.list
	object$n.bootstrap <- param$n.bootstrap
	object	
} # end of update.dpath


# --------------------------------------------------------------------
# Created: 2015-05-27
# Prioritize metacells
# --------------------------------------------------------------------
prioritize <- function(d, direction = NULL, metagene = NULL, distance = 'mgmc', gene.enrichment.score = TRUE, scale.ranking = TRUE, beta = 0.9, mc.cores = 8){

	if (is.null(metagene))
		stop('metagene cannot be NULL')
	
	if (!direction %in% c('progenitor', 'committed') && distance == 'mgmc')
		stop('direction must be either progenitor or committed if distance is mgmc')
	
	if (!distance %in% c('mgmc', 'euclidean', 'KL'))
		stop('distance must be either mgmc, euclidean or KL')

	if (beta <= 0 || beta >= 1)
		stop('beta must be greater than 0 and smaller than 1')
	
	K <- nrow(d$V)	# number of metagenes
	M <- d$grid$xdim * d$grid$ydim	# number of metacells
	N <- nrow(d$U)	# number of genes

	if (!is.vector(metagene) || length(metagene) != K || any(metagene < 0))
		stop(sprintf('metagene must be a %d-length non-negative vector', K))

	metagene <- metagene / sum(metagene)

	cat(sprintf('Prioritizing %s metacells for metagene signature:\n%s\n', direction, paste(sprintf('MG%d:%.3f', 1:K, metagene), collapse = '; ')))
	pb <- txtProgressBar(min = 0, max = length(d$som.list), initial = 0, char = '*', style = 3, width = 20)
	RK <- do.call('rbind', mclapply(1:length(d$som.list), function(r){	# for each repeated run
		V <- d$som.list[[r]]$metacell
		if (distance == 'mgmc'){
			A <- transit.prob(d$som.list[[r]]$A, V, direction = direction)	# transition probability between metacells
			u <- rwr.mcmg(A, V, metagene, beta)$metacell
		}else if (distance == 'euclidean'){
			u <- 1 / (1 + c(rdist(V, t(metagene))))
			u <- u / sum(u)
		}else if (distance == 'KL'){
			V0 <- t(matrix(metagene, nrow = K, ncol = M))
			u <- rowSums(V * (log(V + .Machine$double.eps ) - log(V0 + .Machine$double.eps)))
			u <- 1 / (1 + u)
			u <- u / sum(u)
		}
		setTxtProgressBar(pb, r)
		u
	}, mc.cores = mc.cores, mc.preschedule = FALSE))
	cat('\n')

	# scale so that for each bootstrap sample the sum of metacell rank equal to zero
	if (scale.ranking)
		RK <- RK - replicate(ncol(RK), rowMeans(RK))

	if (!gene.enrichment.score)
		score <- NULL
	else{
		cat(sprintf('Computing the gene enrichment score:\n'))
		pb <- txtProgressBar(min = 0, max = length(d$som.list), initial = 0, char = '*', style = 3, width = 20)
		ES <- Reduce('cBind', mclapply(1:length(d$som.list), function(r){
			W <- metacell.expression(d$V, d$som.list[[r]]$metacell, d$X)	# observed metacell expression
			W <- W + 1	# adding a pseudo count to the observed metacell expression
			w <- 1 / rowSums(W)
			w[is.infinite(w)] <- 0	
			W <- Diagonal(x = w) %*% W	# scale the sum of observed expression in all metacell to one
			setTxtProgressBar(pb, r)
			W %*% RK[r, ]
		}, mc.cores = mc.cores, mc.preschedule = TRUE))
		cat('\n')
		score <- rowSums(ES)
		names(score) <- rownames(ES)
	}

	list(gene = score, metacell = RK[d$best, ])

} # end of prioritize


# --------------------------------------------------------------------
# Created: 2015-05-19
# Preparing the transition probability matrix between metacells
# --------------------------------------------------------------------
transit.prob <- function(A, V, direction = 'committed', p0 = 1e-5){
	K <- ncol(V)
	V <- V + .Machine$double.eps
	a <- summary(A)
	h <- entropy2(V)	# entropy for each metacell
	a[, 3] <- sqrt(rowSums((V[a[, 1], ] - V[a[, 2], ])^2))
	a[, 3] <- exp(-a[, 3])	# converting distance to probability
	a[h[a[, 1]] < h[a[, 2]], 3] <- p0	# set a low probability to reverse entropy links
	A <- sparseMatrix(i = a[, 1], j = a[, 2], x = a[, 3], dims = c(nrow(V), nrow(V)))
	if (direction == 'progenitor')
		A <- t(A)
	w <- 1 / rowSums(A); w[is.infinite(w)] <- 0
	A <- Diagonal(x = w) %*% A
	A
} # end of transit.prob


# --------------------------------------------------------------------
# Created: 2015-04-30
# Random walk with restart on a metagene-metacell graph
# --------------------------------------------------------------------
rwr.mcmg <- function(A, V, metagene = NULL, beta = 0.9){
	
	K <- ncol(V)
	M <- nrow(V)
	
	G.mcmg <- V	# metacell -> metagene graph

	# metagene -> metacell graph
	G.mgmc <- t(V)
	w <- 1 / rowSums(G.mgmc)
	w[is.infinite(w)] <- 0
	G.mgmc <- Diagonal(x = w) %*% G.mgmc

	G.mg <- Diagonal(n = K)

	w <- 1/ rowSums(A); w[is.infinite(w)] <- 0; A <- Diagonal(x = w) %*% A

	G <- rBind(
		cBind(beta * G.mg, (1 - beta) * G.mgmc), 
		cBind((1 - beta) * G.mcmg, beta * A)
	)
	v <- rep(0, K + M)
	v[1:K] <- metagene	# setting the start metagene
	u <- page.rank(graph.adjacency(as(G, 'dgCMatrix'), mode = 'directed', weighted = TRUE), personalized = v)$vector
	u.mg <- u[1:K]
	u.mc <- u[(K + 1):(K + M)]	# extract the probability on metacell
	list(metagene = u.mg / sum(u.mg), metacell = u.mc / sum(u.mc))

} # end rwr.mcmg


# --------------------------------------------------------------------
# Created: 2015-02-03
# Visualize the coefficients(U) and basis(V) of a list of selected genes
# --------------------------------------------------------------------
plot.dpath <- function(x, ...){

	param <- list(...)
	type <- param$type

	N <- nrow(x$Xp)
	K <- nrow(x$V)
	M <- ncol(x$V)

	if (is.null(type)){
		cat('type must be specified as one of the following value:\n')
		cat('          markers: metagene coefficients and basis, as well as expression levels for selected marker genes\n')
		cat(' metagene.entropy: metagene entropy of metacells on the SOM\n')
		cat('cell.distribution: distribution of a specified group of cells on the SOM\n')
		cat('  gene.expression: gene expression level on the SOM\n')
		cat('   prioritization: top ranking genes for prioritized metacells with specified progenitor or committed state\n')
		stop('type cannot be NULL')			
	}

	# set the color for each metagene
	if (is.null(param$col.metagene))
		param$col.metagene <- rainbow(K)
	else{
		if (length(param$col.metagene) != K)
			stop('length of col.metagene must be equal to the number of metagene')
		
		is.color <- sapply(param$col.metagene, function(y) tryCatch(is.matrix(col2rgb(y)), error = function(e) FALSE))
		if (any(!is.color))
			stop('col.metagene contains non-color string')
	}

	if (type == 'markers'){

		# -----------------------------------------------------------------------------------------------
		# metagene coefficients and basis, as well as expression levels for selected marker genes
		# -----------------------------------------------------------------------------------------------

		if (is.null(param$gene)){
			gs <- rownames(x$Xp)
		}else{
			is.included <- param$gene %in% rownames(x$Xp) 
			if (sum(is.included) == 0)
				stop('None of supplied genes are included')
			else
				cat(sprintf('%d of %d supplied genes are included\n', sum(is.included), length(param$gene)))
			gs <- param$gene[is.included]
		}

		gs <- gs[rowSums(d$U[gs, ] > 0) > .Machine$double.eps]	# remove the genes which metagene bassis are all zero

		# panel 1: heatmap for metagenes coefficients
		x.left <- 0.05; x.right <- 0.2; y.bottom <- 0.1; y.top <- 0.9
		cls <- cluster(x, method = 'hopach', hopach.dist = 'euclid', min.weight = 0, hopach.cluster = 'greedy')
		for (k in 1:K){
			par(fig = c(x.left + (x.right - x.left) * ((k - 1) / K), x.left + (x.right - x.left) * (k / K), y.bottom, y.top), mar = c(1, 0, 6, 0), new = ifelse(k == 1, FALSE, TRUE))
			image(t(as.matrix(x$V[k, cls$order])), col = colorpanel(100, low = 'white', high = param$col.metagene[k]), breaks = seq(0, 1, length.out = 101), axes = FALSE)
			mtext(k, side = 3)
		}

		# panel 2: heatmap for metagene basis
		x.left <- 0.2; x.right = 1; y.bottom <- 0.025; y.top <- 0.1
		U <- as.matrix(x$U[gs, ])
		rn <- rownames(U); U <- diag(1 / rowSums(U)) %*% U; rownames(U) <- rn
		hc2 <- hclust(dist(U))	# clustering selected genes
		jj <- rownames(U)[hc2$order]
		U <- U[jj, ]

		for (k in 1:K){
			par(fig = c(x.left, x.right, y.bottom + (y.top - y.bottom) * ((k - 1) / K), y.bottom + (y.top - y.bottom) * (k / K)), mar = c(0, 5, 0, 5), new = TRUE)
			image(U[, k, drop = FALSE], col = colorpanel(100, low = 'white', high = param$col.metagene[k]), axes = FALSE, breaks = seq(0, 1, length.out = 101))
			mtext(k, side = 4, las = 2, line = 1)
		}

		# panel 3: barplot for median expression levels of each gene
		x.left <- 0.2; x.right <- 1; y.bottom <- 0.9; y.top <- 1
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(0, 5, 2, 5), new = TRUE)

		X <- x$X[jj, cls$order]	
		X[X < 1] <- 0
		X <- diag(1 / apply(X, 1, max)) %*% X	# scale so that each gene's maximum expression is one
		rownames(X) <- gs
	
		x.median <- sapply(gs, function(g){
			if (g %in% rownames(x$Xp))
				median(x$Xp[g, ])
			else
				0
		})
		par(lwd = 3)
		barplot(x.median[jj], names.arg = '', xaxs = 'i', ylab = 'log(TPM + 1)', col = 'white', cex.axis = 1.25, cex.lab = 1, main = 'Median expected expression levels', las = 2)
		par(lwd = 1)

		# panel 4: heatmap for marker genes
		x.left <- 0.2; x.right <- 1; y.bottom <- 0.1; y.top <- 0.9
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(1, 5, 6, 5), new = TRUE)
		image(X, col = colorpanel(100, low = 'black', high = 'green'), axes = FALSE)
		add.grid(X, col = 'black')
		col.axis <- rep('black', length(gs))
		text(y = rep(1.025, length(gs)), x = seq(0, 1, length.out = length(gs)), labels = jj, srt = 90, xpd = TRUE, col = col.axis, cex = 1.3, pos = 4, adj = c(0, 0))

	}else if (type == 'prioritization'){
		
		if (is.null(param$score.metacell))
			stop('score.metacell cannot be NULL')
		
		if (is.null(param$score.gene))
			stop('score.gene cannot be NULL')
		
		if (is.null(param$top))
			param$top <- 50

		if (N != length(param$score.gene))
			stop(sprintf('length of score.gene must be equal to %d', N))
		
		if (length(param$score.metacell) != nrow(x$grid$pts))
			stop(sprintf('length of score.metacell must be equal to %d', nrow(x$grid$pts)))
		
		gs <- names(sort(param$score.gene, decreasing = TRUE)[1:param$top])

		X <- metacell.expression(x$V, x$som.list[[x$best]]$metacell, x$X)	# observed expression levels in metacells

		# clustering the metacells by the code
		D <- Reduce('+', lapply(x$som.list, function(s) as.matrix(dist(s$metacell)))) / length(x$som.list)
		h <- hclust(as.dist(D))$order

		# panel: aggregated expression levels of top ranked genes
		x.left <- 0; x.right <- 0.2; y.bottom <- 0.8; y.top <- 1
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(1, 4, 2, 1), new = FALSE)
		somplot(x$grid, property = param$score.metacell, topo = 'hex', main = '', col = colorpanel(100, low = 'black', mid = 'white', high = 'purple'), col.border = 'black')

		# panel: heatmap for metagenes
		x.left <- 0.05; x.right <- 0.2; y.bottom <- 0; y.top <- 0.8
		for (k in 1:K){
			par(fig = c(x.left + (x.right - x.left) * ((k - 1) / K), x.left + (x.right - x.left) * (k / K), y.bottom, y.top), mar = c(1, 0, 1, 0), new = TRUE)
			image(t(as.matrix(x$som.list[[x$best]]$metacell[h, k])), col = colorpanel(100, low = 'white', high = param$col.metagene[k]), axes = FALSE)
#			add.grid(t(as.matrix(x$som.list[[x$best]]$metacell[h, k])))
			mtext(k, side = 3)
		}

		# panel: observed expression levels at each metacell for top genes
		x.left <- 0.2; x.right <- 0.95; y.bottom <- 0; y.top <- 0.8
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(1, 2, 1, 0), new = TRUE)
		X2 <- X[gs, h]
		X2 <- diag(1 / apply(X2, 1, max)) %*% X2
		image(X2, col = colorpanel(100, low = 'black', high = 'green'), axes = FALSE)
#		add.grid(X2, col = 'black')

		# panel: metacell prioritization score
		x.left <- 0.95; x.right <- 1; y.bottom <- 0; y.top <- 0.8
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(1, 1, 1, 1), new = TRUE)
		Z <- t(param$score.metacell[h])
		image(Z, col = colorpanel(100, low = 'black', mid = 'white', high = 'purple'), axes = FALSE)
#		add.grid(Z, col = 'black')
#		mtext('RWR score', 3, las = 2, cex = 1, line = 0.5)

		# panel: gene enrichment score in prioritized progenitor metacells
		x.left <- 0.2; x.right <- 0.95; y.bottom <- 0.8; y.top <- 1
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(0, 2, 14, 0), new = TRUE)
		Z <- matrix(param$score.gene[gs], nrow = length(gs), ncol = 1)
		image(Z, col = colorpanel(100, low = 'blue', mid = 'white', high = 'red'), breaks = seq(min(param$score.gene) - 1e-10, max(param$score.gene) + 1e-10, length.out = 101), axes = FALSE)
		coords <- add.grid(Z, col = 'black')
#		mtext('enrichment', 2, las = 3, cex = 1, line = 0.5)

		col.axis <- rep('black', length(gs))
		text(y = rep(1.025, length(gs)), x = coords$vline[-length(coords$vline)], labels = gs, srt = 90, xpd = TRUE, col = col.axis, cex = 1, pos = 4, adj = c(0, 0))

	}else if (type == 'cell.distribution'){

		# -----------------------------------------------------------------------------------------------
		# distribution of a specified group of cells on the SOM
		# -----------------------------------------------------------------------------------------------

		if (is.null(param$n.neighbors))
			param$n.neighbors <- 3
		
		if (is.null(param$cell.group))
			stop('cell.group cannot be NULL')

		u <- t(apply(rdist(t(x$V[, param$cell.group]), x$som.list[[x$best]]$metacell), 1, function(y) order(y)[1:param$n.neighbors]))
		u <- table(factor(c(u), 1:(x$grid$xdim * x$grid$ydim)))
		u <- as.numeric(u)
		x.left <- 0; x.right <- 0.85; y.bottom <- 0; y.top <- 1
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(2, 1, 3, 1))
		somplot(x$grid, property = u / sum(u), topo = 'hex', cex.main = 2, col = colorpanel(100, low = 'black', mid = 'white', high = 'blue'), main = param$main)
		x.left <- 0.85; x.right <- 1; y.bottom <- 0; y.top <- 1
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(2, 0, 2, 3), new = TRUE)
		image(matrix(0:max(u), nrow = 1, ncol = max(u) + 1), col = colorpanel(max(u) + 1, low = 'black', mid = 'white', high = 'blue'), axes = FALSE)
		axis(4, c(0, 1), at = c(0, 1), labels = c(0, max(u)), las = 2, tick = TRUE)
		
	}else if (type == 'cell.distribution.ratio'){

		if (is.null(param$n.neighbors))
			param$n.neighbors <- 3

		if (is.null(param$cell.group))
			stop('cell.group cannot be NULL')

		v <- lapply(param$cell.group, function(g){
			u <- t(apply(rdist(t(x$V[, g]), x$som.list[[x$best]]$metacell), 1, function(y) order(y)[1:param$n.neighbors]))
			u <- table(factor(c(u), 1:(x$grid$xdim * x$grid$ydim)))
			as.numeric(u / sum(u))
		})
		v <- log2((v[[1]] + 1) / (v[[2]] + 1))
		somplot(x$grid, property = v, topo = 'hex', main = 'Ratio', col = colorpanel(100, low = 'green', mid = 'black', high = 'red'))

	}else if (type == 'metagene.entropy'){

		# -----------------------------------------------------------------------------------------------
		# metagene entropy of metacells on the SOM
		# -----------------------------------------------------------------------------------------------
		par(mfrow = c(1, 3), mar = c(1, 2, 3, 1))
		entropy <- apply(x$som.list[[x$best]]$metacell, 1, function(h) -sum(h * log(h + 1e-100)))	# entropy for each metacell
		somplot(x$grid, property = entropy, topo = 'hex', main = 'Metagene entropy', cex.main = 2, col = heat.colors(100), col.border = 'white')
		z <- matrix(entropy, nrow = x$grid$xdim, ncol = x$grid$ydim)
		col <- heat.colors(100)
		colcode <- matrix(col[round( (z - min(z)) / (max(z)- min(z)) * (length(col) - 1)) + 1], nrow = nrow(z), ncol = ncol(z))
		persp(1:x$grid$xdim, 1:x$grid$ydim, z, theta = 10, phi = 30, xlab = '', ylab = '', zlab = 'Entropy', col = colcode, main = "Waddington's epigenetic landscape", cex.main = 2, expand = 0.25, shade = 0.25)
		somplot(x$grid, property = x$som.list[[x$best]]$metacell, topo = 'hex', main = 'Metagene distribution', cex.main = 2, col = do.call('cbind', lapply(1:K, function(k) colorpanel(100, low = 'white', high = param$col.metagene[k]))), col.border = 'white')

	}else if (type == 'metagene.boxplot'){

		if (is.null(param$cell.group))
			stop('cell.group cannot be NULL')

		entropy.list <- lapply(param$cell.group, function(g) apply(x$V[, g, drop = FALSE], 2, function(v) -sum(v * log(v + 1e-100))))
		z <- do.call('rbind', lapply(1:length(entropy.list), function(i) data.frame(name = names(param$cell.group)[i], entropy = entropy.list[[i]])))
		z <- transform(z, name = factor(name, names(param$cell.group)))
		ggplot(z, aes(name, entropy)) + geom_boxplot(notch = TRUE) + labs(x = '', y = 'Metagene entropy') + theme(axis.title.y = element_text(size = rel(1)), axis.text.y = element_text(size = rel(1.5)), axis.text.x = element_text(size = rel(1.5)))

	}else if (type == 'gene.expression'){

		if (is.null(param$gene))
			stop('gene cannot be NULL')
		
		if (!any(param$gene %in% rownames(x$X)))
			stop(sprintf('gene %s does not exist in the input expression matrix', param$gene))

		x.left <- 0; x.right <- 0.85; y.bottom <- 0; y.top <- 1
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(2, 1, 3, 1))
		X <- metacell.expression(x$V, x$som.list[[x$best]]$metacell, x$X, k = 5)	# observed expression levels in metacells
		somplot(x$grid, property = X[param$gene, ], topo = 'hex', main = param$gene, cex.main = 2, col = colorpanel(100, low = 'black', high = 'green'), col.border = 'black')
		x.left <- 0.85; x.right <- 1; y.bottom <- 0; y.top <- 1
		par(fig = c(x.left, x.right, y.bottom, y.top), mar = c(2, 0, 2, 3), new = TRUE)
		image(matrix(1:100, nrow = 1, ncol = 100), col = colorpanel(100, low = 'black', high = 'green'), axes = FALSE)
		axis(4, c(0, 1), at = c(0, 1), labels = sprintf('%.1f', c(0, max(X[param$gene, ]))), las = 2, tick = TRUE)

	}else if (type == 'gene.expression.grid'){

		if (is.null(param$gene))
			stop('gene must not be NULL when plotting type is "markers"')
		else{
			is.included <- param$gene %in% rownames(x$X)
			if (sum(is.included) == 0)
				stop('None of supplied genes are included')
			else
				cat(sprintf('%d of %d supplied genes are included\n', sum(is.included), length(param$gene)))
		}

		param$gene <- param$gene[is.included]
		X <- metacell.expression(x$V, x$som.list[[x$best]]$metacell, x$X)	# observed expression levels in metacells
		for (i in 1:length(param$gene)){
			somplot(x$grid, property = X[param$gene[i], ], topo = 'hex', main = param$gene[i], cex.main = 2, col = colorpanel(100, low = 'black', high = 'green'), col.border = 'black')
		}

	}else if (type == 'cluster'){

		if (is.null(param$center))
			stop('center must not be NULL when plotting type is "cluster"')

		if (is.null(param$cell.group))
			stop('cell.group must not be NULL when plotting type is "cluster"')

		if (is.null(param$cluster))
			stop('cluster must not be NULL when plotting type is "cluster"')
		
		center <- param$center
		h <- nrow(center) # number of centers
		cell.group <- param$cell.group
		cell.group <- do.call('cbind', cell.group)
		g <- param$cluster
		g <- split(1:length(g), list(factor(g, 1:h)))
		C <- do.call('rbind', lapply(g, function(i) colSums(cell.group[i, , drop = FALSE]))) # count how many cells belong to each cluster in each cell group
#		C2 <- round(C %*% diag(1 / colSums(C)) * 100); colnames(C2) <- colnames(C); C <- C2

		par(fig = c(0.05, 0.3, 0, 1), mar = c(3, 2, 10, 1), new = FALSE)
		image(log(t(C[h:1, , drop = FALSE]) + 1), col = colorpanel(100, low = 'white', high = 'lightblue'), axes = FALSE)
		axis(2, seq(0, 1, length.out = h), sprintf('C%d', h:1), tick = FALSE, las = 2, cex.axis = 1.5)
		axis(3, seq(0, 1, length.out = ncol(C)), colnames(C), las = 2, tick = FALSE, cex.axis = 1.5)
		coord <- expand.grid(y = seq(0, 1, length.out = h), x = seq(0, 1, length.out = ncol(C)))
		mtext('# cells', 1, cex = 1.5, line = 1)
		C[C == 0] <- ''
		text(coord[, 'x'], coord[, 'y'], c(C[h:1, , drop = FALSE]), cex = 1.5)

		x.left <- 0.3; x.right <- 0.7; y.bottom <- 0; y.top <- 1
		for (k in 1:K){
			par(fig = c(x.left + (x.right - x.left) * ((k - 1) / K), x.left + (x.right - x.left) * (k / K), y.bottom, y.top), mar = c(3, 0, 10, 0), new = TRUE)
			image(t(as.matrix(center[h:1, k])), col = colorpanel(100, low = 'white', high = rainbow(K)[k]), axes = FALSE, breaks = seq(0, 1, length.out = 101))
			add.grid(t(as.matrix(center[h:1, k])), col = 'white')
			if (k == round(K / 2))
				mtext('Metagene signature', 1, cex = 1.5, line = 1)
			mtext(k, 3, cex = 1.5, line = 1)
		}

		par(fig = c(0.7, 0.95, 0, 1), mar = c(3, 1, 10, 1), new = TRUE)
		barplot(rev(entropy2(center)), horiz = TRUE, names.arg = '', axes = FALSE, yaxs = 'i')
		axis(3, seq(0, 2, by = 0.5), cex.axis = 1.5)
		mtext('Metagene entropy', 1, cex = 1.5, line = 1)

	}
	
} # end of plot.dpath


# --------------------------------------------------------------------
# Created: 2015-06-01
# Cluster metacells
# --------------------------------------------------------------------
cluster <- function(d, method = 'hopach', ...){

	param <- list(...)
	V <- t(d$V)

	if (method == 'hopach'){

		if (is.null(param$min.weight))
			param$min.weight <- 0.05
		
		if (is.null(param$hopach.dist))
			param$hopach.dist <- 'euclid'

		if (is.null(param$hopach.cluster))
			param$hopach.cluster <- 'best'
		
		if (is.null(param$remove.singleton.cluster))
			param$remove.singleton.cluster <- FALSE

		D <- exp(-d$S); D <- diag(1 / rowSums(D)) %*% D
		hp <- hopach(as.dist(D), d = param$hopach.dist, cluster = param$hopach.cluster, verbose = TRUE)
		sp <- split(1:nrow(V), list(hp$clust$labels))
		if (param$remove.singleton.cluster)
			sp <- sp[hp$clust$sizes > 1]	# remove the singleton clusters 
		Vm <- V[hp$clust$medoids, , drop = FALSE]
		if (param$remove.singleton.cluster)
			Vm <- Vm[hp$clust$sizes > 1, , drop = FALSE]
		Vm <- Vm[nrow(Vm):1, , drop = FALSE]
		cls <- rep(NA, nrow(V))
		cls[unlist(sp)] <- rep(length(sp):1, sapply(sp, length))
		list(center = Vm, cluster = cls, order = hp$clust$order)
	}else if (method == 'cmeans'){
		require(cluster)
		require(e1071)
		gscmn <- clusGap(V, FUN = cmeans, K.max = 15, B = 20)
		K <- which(diff(gscmn$Tab[, 'gap']) < 0)[1]
		cmn <- cmeans(V, K)
		list(center = cmn$center, cluster = cmn$cluster, order = order(cmn$cluster))
	}else
		stop(sprintf('method %s is not supported'))

} # end of cluster


# --------------------------------------------------------------------
# Created: 2014-12-05
# Get observed expression in metacell
# --------------------------------------------------------------------
metacell.expression <- function(V, H, X, k = 3, min.tpm = 1){
	nn <- knnx.index(t(V), H, k = k)
	A <- sparseMatrix(i = rep(1:nrow(H), k), j = c(nn), x = rep(1 / k, length(nn)), dims = c(nrow(H), ncol(V)))
	X <- as.matrix(X %*% t(A))
	X[X <= log(1 + min.tpm)] <- 0
	X
} # end of metacell.expression


# --------------------------------------------------------------------
# Created: 2014-06-27
# log density of Poission distribution
# --------------------------------------------------------------------
ldpois <- function(k, mu){

	mu <- mu + .Machine$double.eps
	k <- k + .Machine$double.eps

	if (any(k <= -1))
		stop('k must be greater than -1')
	
	if (any(mu <= 0))
		stop('mu must be all positive')

	k * log(mu) - mu - lfactorial(k)	

} # end of ldpois


# --------------------------------------------------------------------
# Created: 2015-04-28
# Fitting a self-organizing map using bootstrapped cells
# --------------------------------------------------------------------
fitsom <- function(V, som.grid = NULL, repeat.bootstrap = 100, n.bootstrap = 1000, mc.cores = 8){
	M <- ncol(V)
	n.metacell <- som.grid$ydim * som.grid$xdim	# number of metacell
	cat(sprintf('building %d %dx%d SOM by using %d bootstraped cells\n', repeat.bootstrap, som.grid$xdim, som.grid$ydim, n.bootstrap))
	pb <- txtProgressBar(min = 0, max = repeat.bootstrap, initial = 0, char = '*', style = 3, width = 20)
	som.list <- mclapply(1:repeat.bootstrap, function(b){
		set.seed(b)
		model <- som(as.matrix(t(V[, sample(1:M, n.bootstrap, replace = TRUE)])), grid = som.grid)	# fit a SOM model by bootstraped samples
		A <- do.call('rbind', lapply(1:n.metacell, function(me) data.frame(from = which(abs(sqrt((model$grid$pts[, 'x'] - model$grid$pts[me, 'x'])^2 + (model$grid$pts[, 'y'] - model$grid$pts[me, 'y'])^2) - 1) < 1e-5),	 to = me)))	# find the neighboring metacells
		A <- sparseMatrix(i = A[, 'from'], j = A[, 'to'], dims = c(n.metacell, n.metacell))
		metacell <- model$codes
		setTxtProgressBar(pb, b)
		list(A = A, metacell = metacell)
	}, mc.cores = mc.cores, mc.preschedule = FALSE, mc.set.seed = FALSE)
	cat('\n')
	som.list
} # end of fitsom


# --------------------------------------------------------------------
# Created: 2015-02-03
# Plot SOM hex plot
# --------------------------------------------------------------------
somplot <- function(
	grid, 
	property, 
	A = NULL, 
	topo = 'hex', 
	col = heat.colors(100), 
	highlight = NULL, 
	col.highlight = 'yellow', 
	text.highlight = NULL, 
	lwd.highlight = 4,
	cex.text.highlight = 1, 
	col.text.highlight = 'black',
	col.path = 'black', 
	color.key = FALSE, 
	col.border = 'black', 
	length.path = 0.05,
	lwd.path = 1, 
	offset = 0.35,
	...
){

	if (topo == 'hex')
		r <- 0.5 / cos(pi * 1/ 6)	# radius of the hex
	else
		stop(sprintf('topo %s is not supported', topo))

	n <- nrow(grid$pts)

	colcode <- rep('white', n)
	if (class(property) == 'numeric'){
		colcode <- col[round( (property - min(property)) / (max(property)- min(property)) * (length(col) - 1)) + 1]
	}else if (class(property) == 'matrix'){
		colcode <- do.call('cbind', lapply(1:ncol(property), function(i) col[round( (property[, i] - min(property[, i])) / (max(property[, i])- min(property[, i])) * (nrow(col) - 1)) + 1, i]))
		colcode <- sapply(1:n, function(i) {
			s <- order(property[i, ], decreasing = TRUE)[1:2]
			hex(mixcolor(0.5, hex2RGB(col2hex(colcode[i, s[1]])), hex2RGB(col2hex(colcode[i, s[2]]))))
		})
	}else
		stop('class of property should be either numeric or matrix')

	plot(0, 0, type = 'n', axes = FALSE, xlim = c(min(grid$pts[, 'x']) - 0.5, max(grid$pts[, 'x']) + 0.5), ylim = c(min(grid$pts[, 'y']) - 0.5, max(grid$pts[, 'y'] + 0.5)), xlab = '', ylab = '', ...)

	for (i in 1:n){
	  polygon(
			grid$pts[i, 'x'] + r * cos(pi * seq(1 / 6, 2 + 1 / 6, by = 1 / 3)),
			grid$pts[i, 'y'] + r * sin(pi * seq(1 / 6, 2 + 1 / 6, by = 1 / 3)),
			col = colcode[i], border = col.border
		)
	}
	if (!is.null(highlight)){
		for (i in highlight){
		  polygon(
				grid$pts[i, 'x'] + r * cos(pi * seq(1 / 6, 2 + 1 / 6, by = 1 / 3)),
				grid$pts[i, 'y'] + r * sin(pi * seq(1 / 6, 2 + 1 / 6, by = 1 / 3)),
				col = colcode[i], border = col.highlight, lwd = lwd.highlight
			)
			if (!is.null(text.highlight))
				text(grid$pts[highlight, 'x'], grid$pts[highlight, 'y'], text.highlight, cex = cex.text.highlight, col = col.text.highlight)
		}
	}

	if (!is.null(A)){
		A <- summary(A)
		from.x <- grid$pts[A[, 1], 'x']
		from.y <- grid$pts[A[, 1], 'y']
		to.x <- grid$pts[A[, 2], 'x']
		to.y <- grid$pts[A[, 2], 'y']
		arrows(from.x + (to.x - from.x) * offset, from.y + (to.y - from.y) * offset, to.x + (from.x - to.x) * offset, to.y + (from.y - to.y) * offset, length = length.path, lwd = lwd.path, col = col.path)
	}

} # end of somplot


# --------------------------------------------------------------------
# Created: 2015-04-21
# Add grid lines to the heatmap
# --------------------------------------------------------------------
add.grid <- function(x, col = 'gray', cex = 0.1, v = TRUE, h = TRUE){

	if (!is.matrix(x))
		stop('x must be a matrix')

	if (ncol(x) == 1)
		ch <- 1
	else
		ch <- 1 / (ncol(x) - 1)

	if (nrow(x) > 1)
		cw <- 1 / (nrow(x) - 1)
	
	vline <- NULL
	if (v){
		if (nrow(x) == 1)
			vline <- c(-1, 1)
		else
			vline <- seq(-cw / 2, 1 + cw / 2, length.out = nrow(x) + 1)
		abline(v = vline, col = col, cex = cex, xpd = FALSE)
	}

	hline <- NULL
	if (h){
		if (ncol(x) == 1)
			hline <- c(-1, 1)
		else
			hline <- seq(-ch / 2, 1 + ch / 2, length.out = ncol(x) + 1)
		abline(h = hline, col = col, cex = cex, xpd = FALSE)	
	}
	list(vline = vline, hline = hline)	
} # end of add.grid




# --------------------------------------------------------------------
# Created: 2015-04-21
# Predict the shortest differentiation pathways from predicted 
# progenitor states to committed states
# --------------------------------------------------------------------
differentiation.path.p2c <- function(d, metagene = NULL, prob = NA){
	
	if (is.null(metagene))
		stop('metagene must be specified')
	
	K <- nrow(d$V)	# number of metagenes
	M <- nrow(d$grid$pts)

	if (any(metagene < 1) || any(metagene > K))
		stop(sprintf('metagene must be between 1 and %d', K))

	# prioritize the metacells for committed states
	committed <- lapply(metagene, function(k){
		v <- rep(0, K); v[k] <- 1
		prioritize(d, metagene = v, direction = 'committed', gene.enrichment.score = FALSE, scale.ranking = FALSE)
	})

	# prioritze the metacells for common progenitor states
	v <- rep(0, K); v[metagene] <- 1; v <- v / sum(v)
	progenitor <- prioritize(d, metagene = v, direction = 'progenitor', gene.enrichment.score = FALSE, scale.ranking = FALSE)

	if (is.na(prob)){
		mcc <- lapply(committed, function(x) which.max(x$metacell))
		mcp <- which.max(progenitor$metacell)
	}else{
		mcc <- lapply(committed, function(x) which(x$metacell > prob))
		mcp <- which(progenitor$metacell > prob)
	}

	A <- transit.prob(d$som.list[[d$best]]$A, d$som.list[[d$best]]$metacell, direction = 'progenitor')	# transition probability between metacells
	A <- summary(A)
	A[, 3] <- -log(A[, 3])	# convert similarty to distance
	A <- sparseMatrix(i = A[, 1], j = A[, 2], x = A[, 3], dims = c(M, M))
	A <- graph.adjacency(A, mode = 'directed', weighted = TRUE)
	paths <- lapply(mcc, function(to) unlist(lapply(mcp, function(from) lapply(get.all.shortest.paths(A, from = from, to = to)$res, as.vector)), recursive = FALSE))
	paths
#	A <- do.call('rbind', lapply(unlist(paths, recursive = FALSE), function(p) cbind(from = p[1:(length(p) - 1)], to = p[2:length(p)])))
#	sparseMatrix(i = A[, 'from'], j = A[, 'to'], dims = c(M, M))
	
} # end of differentiation.path.p2c


# --------------------------------------------------------------------
# Created: 2015-05-15
# Compute the KL divergence
# --------------------------------------------------------------------
kldist <- function(V, A = NULL){
	V <- V + .Machine$double.eps
	if (is.null(A))
		a <- expand.grid(from = 1:nrow(V), to = 1:nrow(V))
	else
		a <- summary(as(A, 'dgCMatrix'))[, 1:2]
	a <- cbind(a, dist = rowSums(V[a[, 1], ] * (log(V[a[, 1], ]) - log(V[a[, 2], ]))))	
	as.dist(sparseMatrix(i = a[, 1], j = a[, 2], x = a[, 3], dims = c(nrow(V), nrow(V))))
} # end of kldist


# --------------------------------------------------------------------
# Created: 2015-05-19
# Compute metagene entropy
# --------------------------------------------------------------------
entropy2 <- function(x) -rowSums(x * log(x + .Machine$double.eps))


# --------------------------------------------------------------------
# Created: 2015-05-21
# Convert paths to a graph
# --------------------------------------------------------------------
path2graph <- function(path, n){
	a <- do.call('rbind', lapply(path, function(p) if (length(p) > 1) cbind(from = p[1:(length(p) - 1)], to = p[2:length(p)])))
	sparseMatrix(i = a[, 'from'], j = a[, 'to'], dims = c(n, n))
} # end of path2graph


